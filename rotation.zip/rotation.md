```python
import numpy as np
import cv2 as cv
from matplotlib import pyplot as plt
```


```python
#translation
img = cv.imread('1.jpg',0)
rows,cols = img.shape
M = np.float32([[1,0,100],[0,1,50]])
dst = cv.warpAffine(img,M,(cols,rows))
cv.imshow('img',dst)
cv.waitKey(0)
cv.destroyAllWindows()
```


```python
#rotation
img = cv.imread('1.jpg',0)
rows,cols = img.shape
# cols-1 and rows-1 are the coordinate limits.
M = cv.getRotationMatrix2D(((cols-1)/2.0,(rows-1)/2.0),90,1)
dst = cv.warpAffine(img,M,(cols,rows))
#cv.imshow('img',dst)
plt.subplot(121),plt.imshow(img),plt.title('Input')
plt.subplot(122),plt.imshow(dst),plt.title('Output')
plt.show()
cv.waitKey(0)
cv.destroyAllWindows()
```


    
![png](output_2_0.png)
    



```python
#scaling
img=cv.imread('1.jpg',cv.IMREAD_COLOR)
resized=cv.resize(img,None,fx=1,fy=2,interpolation=cv.INTER_CUBIC)
#cv.imshow("original pic",img)
#cv.imshow("resized pic",resized)
plt.subplot(121),plt.imshow(img),plt.title('Input')
plt.subplot(122),plt.imshow(resized),plt.title('Output')
plt.show()
cv.waitKey()
cv.destroyAllWindows()

```


    
![png](output_3_0.png)
    



```python
#Perspective Transformation
img = cv.imread('1.jpg')
rows,cols,ch = img.shape
pts1 = np.float32([[56,65],[150,52],[28,387],[150,390]])
pts2 = np.float32([[0,0],[300,0],[0,300],[300,300]])
M = cv.getPerspectiveTransform(pts1,pts2)
dst = cv.warpPerspective(img,M,(300,300))
plt.subplot(121),plt.imshow(img),plt.title('Input')
plt.subplot(122),plt.imshow(dst),plt.title('Output')
plt.show()
```


    
![png](output_4_0.png)
    



```python

```


```python

```


```python

```
